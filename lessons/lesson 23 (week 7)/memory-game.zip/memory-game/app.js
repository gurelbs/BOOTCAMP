let arr = [1, 2, 3, 4, 5, 6]
let cardNum = [...arr, ...arr]
cardNum = cardNum.sort(() => 0.5 - Math.random())
const $ = x => document.querySelector(x)
const game = $('.game')
const cards = $('.cards')
const score = $('.score')
const start = $('.start')
const allCard = document.querySelectorAll('.card')



const createCard = () => {
    cardNum.forEach((number, i) => {
        let card = document.createElement('div')
        card.classList.add(`card`, 'color-transparent')
        card.setAttribute('id', `${i}`)
        card.setAttribute('data-number', number)
        cards.appendChild(card)
    })
}
createCard()

const state = {
    numbers: [],
    numOfClick: 0,
    score: 0,
    isCurrect: false
}

let cardsChildren = [...cards.children]
const handleClicks = e => {
    if (e.target.classList.contains('card') && state.numOfClick < 2) {

        e.target.classList.add('opacity');
        e.target.classList.remove('color-transparent')
        e.target.textContent = e.target.getAttribute('data-number')

        const showNumber = () => {
            e.target.classList.add('color-transparent')
            e.target.classList.remove('opacity')
            e.target.textContent = ``
        }
        setTimeout(showNumber, 1000)

        if (state.numbers.length < 2) {
            cardsChildren.forEach(card => {
                if (card.getAttribute('id') !== e.target.getAttribute('id')) {
                    state.numbers.push(e.target.getAttribute('data-number'))
                }
            })
        }
        console.log(state.number);
        state.numOfClick++
    }
}

game.addEventListener('click', handleClicks)